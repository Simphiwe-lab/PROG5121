/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poe_part_one;

import javax.swing.JOptionPane;
import static poe_part_one.POE_PART_ONE.RegisterApp.Prompting_user;

/**
 *
 * @author RC_Student_lab
 */
public class POE_PART_ONE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        
        
        
        //
        Prompting_user();




    }

class RegisterApp {

    static void Prompting_user() {
        Register1 app = new Register1();

        String first = JOptionPane.showInputDialog(null,
                "Enter first name:", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (first == null) return;

        String last = JOptionPane.showInputDialog(null,
                "Enter last name:", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (last == null) return;

        String user = JOptionPane.showInputDialog(null,
                "Create username (must contain '_' and be <= 5 chars):", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (user == null) return;

        String pass = JOptionPane.showInputDialog(null,
                "Create password (>=8 chars, include capital, number, special):", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (pass == null) return;

        String cell = JOptionPane.showInputDialog(null,
                "Enter cell number with international code (e.g., +27XXXXXXXXX):", "Registration", JOptionPane.QUESTION_MESSAGE);
        if (cell == null) return;

        // Show registration results
        String regMsg = app.registerUser(first.trim(), last.trim(), user.trim(), pass.trim(), cell.trim());
        JOptionPane.showMessageDialog(null, regMsg, "Registration Results", JOptionPane.INFORMATION_MESSAGE);

        if (app.username != null) {
            String lu = JOptionPane.showInputDialog(null,
                    "Login - Enter username:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (lu == null) return;

            String lp = JOptionPane.showInputDialog(null,
                    "Login - Enter password:", "Login", JOptionPane.QUESTION_MESSAGE);
            if (lp == null) return;

            String loginMsg = app.returnLoginStatus(lu.trim(), lp.trim());
            JOptionPane.showMessageDialog(null, loginMsg, "Login Result", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                    "Registration failed — please run the program again and correct the inputs.",
                    "Registration Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    }
}

